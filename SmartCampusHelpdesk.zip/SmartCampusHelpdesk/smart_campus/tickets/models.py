from django.db import models
#  3   class created (options like title,description, 
# category priority,status,created at , updated att)
#we define everthing- kind of data 

class Ticket(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()

    category = models.CharField(
        max_length=20,
        choices=[
            ('classroom', 'Classroom'),
            ('hostel', 'Hostel'),
            ('network', 'Network')
        ]
    )

    priority = models.CharField(
        max_length=20,
        choices=[
            ('low', 'Low'),
            ('medium', 'Medium'),
            ('high', 'High')
        ]
    )

    status = models.CharField(
        max_length=20,
        choices=[
            ('open', 'Open'),
            ('in-progress', 'In Progress'),
            ('closed', 'Closed')
        ],
        default='open'
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title