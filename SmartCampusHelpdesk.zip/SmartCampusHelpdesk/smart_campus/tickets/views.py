from filecmp import clear_cache

from django.shortcuts import render

# Create your views here.
#allow CRUD method
from rest_framework.decorators import api_view

#use to return json response instead of html
from rest_framework.response import Response

#use to divide records into pages 
from rest_framework.pagination import PageNumberPagination

#used to restrict access only to logged in users(jwt required)
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import permission_classes

#used for advanced search(tilte OR discriptions)
from django.db.models import Q

#importing Ticket model and its serializer.
from .models import Ticket
from .serializers import TicketSerializer

from django.views.decorators.cache import cache_page
from django.utils.decorators import method_decorator


#api supports get and post 
@api_view(['GET', 'POST'])  #to allow http method

#this 60 is seconds ( that data will store only for 60 sec then will earse)
@cache_page(60)
#cache temp memory

#JWT authentication-----------
@permission_classes([IsAuthenticated])
  #only authenticated person can login 


def ticket_list(request):
#GET--------  fetch data
    if request.method == 'GET':
        tickets = Ticket.objects.all()

    
# 8   filtering------------select data with condition 
        category = request.query_params.get('category')
        status = request.query_params.get('status')

# 10 search by title ---------
        search = request.query_params.get('search')

# 9 orderingg---------------sorting
        ordering = request.query_params.get('ordering')

        if category:
            tickets = tickets.filter(category=category)

        if status:
            tickets = tickets.filter(status=status)

        if search:
             tickets = tickets.filter(
             Q(title__icontains=search) |
            Q(description__icontains=search)
    )

        if ordering:
            tickets = tickets.order_by(ordering)

# 7- pagination---------divide records into pages 
        paginator = PageNumberPagination()
        paginator.page_size = 3
        paginated_tickets = paginator.paginate_queryset(tickets, request)


#convert data in json
#return page count,next,previous all page results 
        serializer = TicketSerializer(paginated_tickets, many=True)
        return paginator.get_paginated_response(serializer.data)
    

#POST---------------create data 
    if request.method == 'POST': #new tickets

        #take json into from users 
        serializer = TicketSerializer(data=request.data)
        if serializer.is_valid():  #validate data 
            serializer.save()
            return Response(serializer.data, status=201)  #created-201
        return Response(serializer.errors, status=400)          # bad request -400



@api_view(['GET', 'PUT', 'DELETE', 'PATCH'])
@permission_classes([IsAuthenticated])
def ticket_detail(request, id):

    try:
        ticket = Ticket.objects.get(id=id)
    except Ticket.DoesNotExist:
        return Response({'error': 'not found'}, status=404)
    

#GET-------------- fetch data
    if request.method == 'GET':
        serializer = TicketSerializer(ticket)
        return Response(serializer.data)
    

#PUT------------update full
    if request.method == 'PUT':
        serializer = TicketSerializer(ticket, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=400)
    


#PATCH-------partial update
    if request.method == 'PATCH':
        serializer = TicketSerializer(ticket, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=400)
    

#DELETE--------
    if request.method == 'DELETE':
        ticket.delete()
        clear_cache()    #clear the cache after deletion  
        
        return Response({'message': 'deleted'})