from django.apps import AppConfig


class TicketsConfig(AppConfig):
    name = 'tickets'
