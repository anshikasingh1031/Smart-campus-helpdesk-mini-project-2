from rest_framework import serializers
from .models import Ticket
#importing Ticket model and its serializer.
#convert model into json vic-versa 

class TicketSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Ticket
        fields = '__all__'